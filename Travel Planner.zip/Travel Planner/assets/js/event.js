
let startDate=getStartDate();
let endDate=getEndDate();
fillTimelineNav();
fillWraperTimeline();
fillMilestone();


  function getStartDate()
  {
    let parameters = location.search.substring(1).split("&");
    var temp = parameters[0].split("=");
    l = unescape(temp[1]);
    let startDate = l.split("/")[0]
  
    return startDate;
  }


  function getEndDate()
  {
    let parameters = location.search.substring(1).split("&");
    var temp = parameters[1].split("=");
    let endDate = unescape(temp[1]);
    
    return endDate;
  }


  function showTimelineNav(){

    let i = parseInt(startDate)+1
    let j = parseInt(endDate)
    let str = `<li><span>${startDate}</span></li>\n`;

    for(i;i<j+1;i++){

        str=str+`<li><span>${i}</span></li>\n`
    }
    return str;
  }


  function fillTimelineNav(){
      document.getElementById('timelineNav').innerHTML=showTimelineNav();
  }


  function showWraperTimeline(){
      
     let i = parseInt(startDate)+1
     let j = parseInt(endDate)
     let str=`<h2 class="milestone">${startDate}</h2>\n`+`<div id=day${startDate}></div>\n`
     
     for(i;i<j+1;i++){

        str=str+`<h2 class="milestone">${i}</h2>\n`+`<div id=day${i}></div>\n`
    }
    return str;
  }


  function fillWraperTimeline(){
      document.getElementById('wrapperTimeline').innerHTML=showWraperTimeline();

  }

  function fillMilestone(){

    function getStr(buttonId){

      let str =`<div class=" mt-5 mb-5">`
        +`<div class="row">`
        +`<div class="col-md-6 offset-md-3">`
        +`<ul class="timeline" id=timeline${buttonId}>`
       
        +`</ul>`
        +`</div>`
        +`</div>`
        +`</div>`

        +`<div class="t"> <a href='javascript:void();' id=popover${buttonId} class="btn btn-large btn-primary popover1" rel="popover" data-content='`

        +`<form class="form-inline" role="form">`
        +`<div class="form-group">`

     
        +`<input  id="fromId" class="form-control" type="time" name="From" placeholder="From...">`
        +`<input  id="toId" class="form-control" type="time" name="To" placeholder="To..."><br><br>`
        +`<input  id="placeId" class="form-control" type="text" name="Place" placeholder="Place"><br><br>`
        +`<input  id="remarkId" class="form-control" type="text" name="Remark" placeholder="Remark"><br><br>`

    

       +` <a href="#" class="btn btn-lg btn-success" data-toggle="modal" data-target="#basicModal" id="placeStore">`
        + ` Place Store »`
       +` </a>`
      

     +` <br><br>`
     +` <a id=button${buttonId} class="addEvent btn btn-primary">Add Event »</a>  `
      +`</div>`
     +` </form>`

    + `' >+ Add Event</a>`
    +`</div>`

    return str;
    }
    let i = parseInt(startDate)
    let j = parseInt(endDate)
    for(i;i<j+1;i++){
    document.getElementById(`day${i}`).innerHTML=getStr(i);
    console.log(document.getElementById(`day${i}`))
}
    
  }


let fromTime;
let toTime;
let place;
let remark;

let popId = null;
let flag=0;

$('.popover1').click(function(event){ 
    
    popId=event.target.id
    console.log(popId)
    console.log(event)

    if(flag==0){
        console.log('run2')
    jQuery(function(){

        console.log('run')
        $(`#${popId}`).click();

     });
    flag=1;
    }

    $(`#${popId}`).popover({
        html: 'true',
    placement: 'right',
    title : 'User Info <a href="#" class="close" data-dismiss="alert">&times;</a>'
    })
})

// function addtoev() {
//     var bns = document.querySelector('.t');
//         console.log(bns)
//     for (i = 0; i < bns.length; i++) {
//       bns[i].addEventListener("click", function(event) {
           
//         popId=event.target.id
//         console.log(popId)
//        });
//     }
//   }
  
//   window.addEventListener("load",function() {
//     addtoev();
//   });

//   document.onclick= function (event) {
//       console.log(event)
//     if ( event.target.classList.contains( 'popover1' ) ) {
//        popId= event.target.id
//        console.log(popId)
//      };
//     }


    // $('body').on('click','.popover1',function (event) {

    //     console.log(event.target.id);
    //     if(flag==1){
    //         popId=event.target.id
    //         flag==0;
    //     }
    // })

$('body').on('click','#placeStore',function () {
    $(document).ready(function () {
        $("#basicModal").appendTo("body");
});})


$('body').on('click','.close',function (event) {
    $(".popover").popover('hide');
    flag=0;
    
    // jQuery(function(){
    //     $(`#${popId}`).click();
    //  });
})

$('body').on('click','.addEvent',function (event) {

    $(".popover").popover('hide');

    fromTime=document.getElementById('fromId').value
    toTime=document.getElementById('toId').value
    place=document.getElementById('placeId').value
    remark=document.getElementById('remarkId').value

   

    showEvent(event.target.id);
    flag=0
})

function fillEvent(){
    let str = `<li>`+
    `<a target="_blank" href="https://www.totoprayogo.com/#">New Web Design</a>`+
    `<a href="#" class="float-right">From ${fromTime} To ${toTime} </a>`+
    `<h3>${place}</h3>`+
    `<p>${remark}</p>`+
    `</li>`
    return str
}

function showEvent(childId){
    let timelineId="timeline"+childId.substring(6)
    document.getElementById(timelineId).innerHTML=document.getElementById(timelineId).innerHTML+fillEvent()
}