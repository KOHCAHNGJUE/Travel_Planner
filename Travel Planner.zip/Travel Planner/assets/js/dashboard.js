
let arr=[];
let eventTitle;
let budget;
let date;
let year;
let month;
let day;
let description;

let event;
  
document.querySelector("#submit").addEventListener("click",function(){
    eventTitle=document.querySelector("#eventTitle").value   
    budget=document.querySelector("#budget").value  
    startDate=document.querySelector("#startDate").value
    endDate=document.querySelector("#endDate").value
    year=startDate.substring(0,4)
    month=startDate.substring(5,7)
    day=startDate.substring(8,11)
    day2=endDate.substring(8,11)
    description=document.querySelector("#description").value
    uploadData(day,month,year,eventTitle,description,day2) 
  })

  function uploadData(day,month,year,eventTitle,description,day2){
  var jsondata = {"day": `${day}`,"month": `${month}`,"year":`${year}`,"title":`${eventTitle}`,"description":`${description}`,"day2":`${day2}`};
  var settings = {
  "async": false,
  "crossDomain": true,
  "url": "https://event-51c7.restdb.io/rest/event",
  "method": "POST",
  "headers": {
    "content-type": "application/json",
    "x-apikey": "5ca6bfe002b739057d314313",
    "cache-control": "no-cache"
  },
  "processData": false,
  "data": JSON.stringify(jsondata)
}

$.ajax(settings).done(function (response) {
  console.log(response+"hello");
  async:false
});

}
  var settings = {
    "async": false,
    "crossDomain": true,
    "url": "https://event-51c7.restdb.io/rest/event",
    "method": "GET",
    "headers": {
      "content-type": "application/json",
      "x-apikey": "	5ca6bfe002b739057d314313",
      "cache-control": "no-cache"
    }
  }
  
  $.ajax(settings).done(function (response) {
    console.log(response);
    response.forEach(function(entry) {
      day=entry.day;
      month=entry.month;
      year=entry.year;
      eventTitle=entry.title;
      description=entry.description;
      day2=entry.day2;
      event=fillEvent(day,month,year,eventTitle,description,day2);
      listEvent()
  });;
  async:false
  });

  function listEvent(){
    document.querySelector("#add-event").innerHTML=document.querySelector("#add-event").innerHTML+event;
    
  }

function fillEvent(day,month,year,eventTitle,description,day2){

let newDes=description  

if(newDes==""){
    newDes="No Description"
  }
let event = `<li class=listenthis id=${day+day2}>`+ 
'<time datetime="">'
+`<span class="day">${day}</span>`
+`<span class="month">${month}</span>`
+`<span class="year">${year}</span>`
+"</time>"

+'<div class="info background-img">'
+`<h2 class="title">${eventTitle}</h2>`
+`<p class="desc">${newDes}</p>`
+`<p class="desc hide">${day2} </p>`
// +"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class='goPlan'>>>></button>"
+`<form action="event.html" >`
    +`<input type="text" class='hide' name="day" value=${day}/>`
    +`<input type="text" class='hide' name="day2" value=${day2} />`
    +`<input  type="image" class="paper-plane" src=assets/img/paper-plane.png value="Submit" />`
    +`<input  type="image" class="paper-plane" src=assets/img/dustbin.png value="Submit" />`
+`</form>`
+"</div>"
+`<div class="social hidden" id=social${day+day2}>`
						+`	<ul>`
						+	`	<li class="facebook" style="width:33%;"><a href="#facebook"><span class="fa fa-facebook"></span></a></li>`
						+	`	<li class="twitter" style="width:34%;"><a href="#twitter"><span class="fa fa-twitter"></span></a></li>`
						+	`	<li class="google-plus" style="width:33%;"><a href="#google-plus"><span class="fa fa-google-plus"></span></a></li>`
						+`	</ul>`
			+	`		</div>`
+"</li>"

return event;
  }

$('.listenthis').mouseover(function(event){
  $(`#social${event.currentTarget.id}`).removeClass('hidden')
})

$('.listenthis').mouseleave(function(event){
  $(`#social${event.currentTarget.id}`).addClass('hidden')
})

// $(document).click(function(event) {

//   if(event.target.className="goPlan"){

//     startDate=event.target.parentElement.parentElement.childNodes[0].childNodes[0].innerHTML
//     endDate=event.target.parentElement.parentElement.childNodes[1].childNodes[2].innerHTML
//     console.log(startDate+endDate)
//     console.log(event.target.parentElement.parentElement)

//     window.location.href="event.html"
  
//   }

// });
